# Job Portal React App

A responsive Job Portal built with React and Bootstrap.

## Available Scripts

- `npm install`
- `npm run dev`
- `npm run build`
- `npm run preview`

## MongoDB setup

The API creates the `job_portal` database and its `users` and `jobs` collections automatically on startup. Set these environment variables when MongoDB is not running locally or uses a different database:

```sh
MONGODB_URI=mongodb://127.0.0.1:27017
MONGODB_DB=job_portal
```

Start the API with `npm run server`. The existing sample jobs are inserted only when the `jobs` collection is empty. Jobs can then be created, read, updated, and deleted from the dashboard.

## Notes

- The app includes registration, login, and dashboard pages.
- Job listings are persisted in MongoDB and seeded from the sample data on first startup.
- Search and filter support is included in the dashboard.
