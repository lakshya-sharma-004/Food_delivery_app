import crypto from 'node:crypto';
import express from 'express';
import cors from 'cors';
import { MongoClient } from 'mongodb';
import { jobsData } from '../src/data/jobs.js';

const app = express();
const port = process.env.PORT || 4000;
const sessions = new Map();

const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017';
const mongoDatabaseName = process.env.MONGODB_DB || 'job_portal';
let database;
let users;
let jobs;

app.use(cors());
app.use(express.json());

const hashPassword = (password, salt = crypto.randomBytes(16).toString('hex')) => ({
  salt,
  hash: crypto.scryptSync(password, salt, 64).toString('hex'),
});

const passwordsMatch = (password, user) => {
  const attemptedHash = crypto.scryptSync(password, user.passwordSalt, 64);
  const storedHash = Buffer.from(user.passwordHash, 'hex');
  return attemptedHash.length === storedHash.length && crypto.timingSafeEqual(attemptedHash, storedHash);
};

const publicUser = (user) => ({ id: user.id || user._id, name: user.name, email: user.email, role: user.role });

const mapJob = ({ _id, createdAt, ...job }) => ({ id: _id, ...job });

const validateJob = (job) => {
  if (!job.title?.trim() || !job.company?.trim() || !job.location?.trim() || !job.type?.trim() || !job.description?.trim()) {
    return 'Title, company, location, type, and description are required.';
  }
  return null;
};

const initializeDatabase = async () => {
  const client = new MongoClient(mongoUri, { serverSelectionTimeoutMS: 5000 });
  await client.connect();
  database = client.db(mongoDatabaseName);
  users = database.collection('users');
  jobs = database.collection('jobs');
  await users.createIndex({ email: 1 }, { unique: true });

  if (await jobs.countDocuments() === 0) {
    await jobs.insertMany(jobsData.map(({ id, ...job }) => ({
      ...job,
      _id: String(id),
      createdAt: new Date(),
    })));
  }
};

app.get('/api/health', (_request, response) => {
  response.json({ status: 'ok' });
});

app.get('/api/jobs', async (_request, response) => {
  const rows = await jobs.find().sort({ createdAt: -1, _id: -1 }).toArray();
  response.json({ jobs: rows.map(mapJob) });
});

app.post('/api/jobs', async (request, response) => {
  const validationError = validateJob(request.body);
  if (validationError) return response.status(400).json({ message: validationError });
  const { title, company, location, type, salary = '', image = '', keywords = [], description } = request.body;
  const job = { _id: crypto.randomUUID(), title: title.trim(), company: company.trim(), location: location.trim(), type: type.trim(), salary: salary.trim(), image: image.trim(), keywords, description: description.trim(), createdAt: new Date() };
  await jobs.insertOne(job);
  return response.status(201).json({ job: mapJob(job) });
});

app.put('/api/jobs/:id', async (request, response) => {
  const validationError = validateJob(request.body);
  if (validationError) return response.status(400).json({ message: validationError });
  const { title, company, location, type, salary = '', image = '', keywords = [], description } = request.body;
  const result = await jobs.findOneAndUpdate(
    { _id: request.params.id },
    { $set: { title: title.trim(), company: company.trim(), location: location.trim(), type: type.trim(), salary: salary.trim(), image: image.trim(), keywords, description: description.trim() } },
    { returnDocument: 'after' },
  );
  if (!result) return response.status(404).json({ message: 'Job not found.' });
  return response.json({ job: mapJob(result) });
});

app.delete('/api/jobs/:id', async (request, response) => {
  const result = await jobs.deleteOne({ _id: request.params.id });
  if (result.deletedCount === 0) return response.status(404).json({ message: 'Job not found.' });
  return response.status(204).send();
});

app.post('/api/auth/register', async (request, response) => {
  const { name, email, password, role = 'Applicant' } = request.body;
  const normalizedEmail = email?.trim().toLowerCase();

  if (!name?.trim() || !normalizedEmail || !password || password.length < 6) {
    return response.status(400).json({ message: 'Name, valid email, and a password of at least 6 characters are required.' });
  }

  const { salt, hash } = hashPassword(password);
  const user = {
    id: crypto.randomUUID(),
    name: name.trim(),
    email: normalizedEmail,
    role,
    passwordSalt: salt,
    passwordHash: hash,
  };
  try {
    await users.insertOne({ _id: user.id, name: user.name, email: user.email, role: user.role, passwordSalt: user.passwordSalt, passwordHash: user.passwordHash });
  } catch (error) {
    if (error.code === 11000) return response.status(409).json({ message: 'An account with this email already exists.' });
    throw error;
  }

  return response.status(201).json({ user: publicUser(user) });
});

app.post('/api/auth/login', async (request, response) => {
  const { email, password } = request.body;
  const user = await users.findOne({ email: email?.trim().toLowerCase() });

  if (!user || !passwordsMatch(password || '', user)) {
    return response.status(401).json({ message: 'Email or password is incorrect.' });
  }

  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, user.id);
  return response.json({ token, user: publicUser(user) });
});

initializeDatabase()
  .then(() => app.listen(port, () => console.log(`Job portal API running at http://localhost:${port}`)))
  .catch((error) => {
    console.error('Unable to initialize MongoDB database:', error.message);
    process.exitCode = 1;
  });