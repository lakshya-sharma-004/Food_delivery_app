import { useState } from 'react';
import AppNavbar from './components/AppNavbar.jsx';
import Register from './pages/Register.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import { loginUser, registerUser } from './api.js';

function App() {
  const [activeSection, setActiveSection] = useState('Register');
  const [registeredUser, setRegisteredUser] = useState(null);
  const [loggedIn, setLoggedIn] = useState(false);

  const handleRegister = async (user) => {
    const result = await registerUser(user);
    setRegisteredUser(result.user);
    setActiveSection('Login');
  };

  const handleLogin = async (credentials) => {
    const result = await loginUser(credentials);
    setRegisteredUser(result.user);
    setLoggedIn(true);
    setActiveSection('Dashboard');
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setActiveSection('Login');
  };

  return (
    <>
      <AppNavbar activeSection={activeSection} onSectionChange={setActiveSection} />
      <section className="hero py-5 text-white">
        <div className="container">
          <div className="row justify-content-center text-center">
            <div className="col-lg-8">
              <h1 className="display-5 fw-bold">Find Your Dream Job</h1>
              <p className="lead text-white-75 mb-4">
                Browse curated roles, upload your resume and get suggested matches instantly.
              </p>
              <div className="hero-search d-flex gap-2 justify-content-center mb-3">
                <input className="form-control form-control-lg" placeholder="Job title, skills, or company" />
                <input className="form-control form-control-lg" placeholder="Location (optional)" style={{ maxWidth: 220 }} />
                <button className="btn btn-mint btn-lg">Search</button>
              </div>
              <div className="d-flex gap-2 justify-content-center flex-wrap">
                {['Design', 'Engineering', 'Product', 'Remote', 'Part-time'].map((c) => (
                  <button key={c} className="btn btn-outline-light btn-sm">
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
      <main className="container py-5">
        <div className="row">
          <div className="col-12">
            {activeSection === 'Register' && <Register onRegister={handleRegister} />}
            {activeSection === 'Login' && <Login onLogin={handleLogin} />}
            {activeSection === 'Dashboard' && loggedIn && registeredUser ? (
              <Dashboard user={registeredUser} onLogout={handleLogout} />
            ) : activeSection === 'Dashboard' ? (
              <div className="alert alert-info">Please login to access the dashboard.</div>
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
}

export default App;
