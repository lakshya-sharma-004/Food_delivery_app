const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

const request = async (path, options = {}) => {
  const response = await fetch(`${API_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  const body = await response.json();

  if (!response.ok) {
    throw new Error(body.message || 'Something went wrong.');
  }

  return body;
};

export const registerUser = (user) => request('/auth/register', {
  method: 'POST',
  body: JSON.stringify(user),
});

export const loginUser = (credentials) => request('/auth/login', {
  method: 'POST',
  body: JSON.stringify(credentials),
});

export const getJobs = () => request('/jobs');

export const createJob = (job) => request('/jobs', {
  method: 'POST',
  body: JSON.stringify(job),
});

export const updateJob = (id, job) => request(`/jobs/${id}`, {
  method: 'PUT',
  body: JSON.stringify(job),
});

export const deleteJob = (id) => request(`/jobs/${id}`, {
  method: 'DELETE',
});