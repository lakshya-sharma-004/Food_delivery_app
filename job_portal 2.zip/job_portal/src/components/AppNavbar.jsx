function AppNavbar({ activeSection, onSectionChange }) {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-success sticky-top">
      <div className="container">
        <a className="navbar-brand" href="#">
          JobPortal
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            {['Register', 'Login', 'Dashboard'].map((section) => (
              <li className="nav-item" key={section}>
                <button
                  type="button"
                  className={`btn nav-link text-white ${activeSection === section ? 'active' : ''}`}
                  onClick={() => onSectionChange(section)}
                >
                  {section}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default AppNavbar;
