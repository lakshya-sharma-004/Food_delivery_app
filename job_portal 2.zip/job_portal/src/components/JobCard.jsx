const fallbackImage = new URL('../assets/job-image-placeholder.svg', import.meta.url).href;

function JobCard({ job }) {
  return (
    <div className="card job-card h-100 shadow-sm">
      <img
        className="card-img-top job-image"
        src={job.image || fallbackImage}
        alt={`${job.company} ${job.title}`}
        onError={(event) => {
          if (event.currentTarget.src !== fallbackImage) event.currentTarget.src = fallbackImage;
        }}
      />
      <div className="card-body">
        <div className="d-flex justify-content-between align-items-start gap-2 mb-3">
          <div className="job-card-heading">
            <h5 className="card-title">{job.title}</h5>
            <p className="text-muted mb-1">{job.company}</p>
          </div>
          <span className="badge bg-success text-white flex-shrink-0">{job.type}</span>
        </div>
        <p className="card-text job-description">{job.description}</p>
      </div>
      <div className="card-footer bg-white border-0 d-flex justify-content-between align-items-center gap-2">
        <small className="text-muted">{job.location}</small>
        <strong className="text-success text-end">{job.salary}</strong>
      </div>
    </div>
  );
}

export default JobCard;
