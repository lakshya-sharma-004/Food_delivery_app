import { useEffect, useMemo, useState } from 'react';
import JobCard from '../components/JobCard.jsx';
import { createJob, deleteJob, getJobs, updateJob } from '../api.js';

const emptyJob = { title: '', company: '', location: '', type: 'Full-time', salary: '', image: '', keywords: '', description: '' };

function Dashboard({ user, onLogout }) {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('All');
  const [jobsData, setJobsData] = useState([]);
  const [loadError, setLoadError] = useState('');
  const [jobForm, setJobForm] = useState(emptyJob);
  const [editingJobId, setEditingJobId] = useState(null);
  const [jobMessage, setJobMessage] = useState('');

  useEffect(() => {
    getJobs()
      .then((result) => setJobsData(result.jobs))
      .catch((error) => setLoadError(error.message));
  }, []);

  const refreshJobs = () => getJobs().then((result) => setJobsData(result.jobs));

  const handleJobSubmit = async (event) => {
    event.preventDefault();
    setJobMessage('');
    const payload = {
      ...jobForm,
      keywords: jobForm.keywords.split(',').map((keyword) => keyword.trim()).filter(Boolean),
    };
    try {
      if (editingJobId) await updateJob(editingJobId, payload);
      else await createJob(payload);
      setJobForm(emptyJob);
      setEditingJobId(null);
      setJobMessage(editingJobId ? 'Job updated.' : 'Job created.');
      await refreshJobs();
    } catch (error) {
      setJobMessage(error.message);
    }
  };

  const startEditing = (job) => {
    setEditingJobId(job.id);
    setJobForm({ ...job, keywords: job.keywords.join(', ') });
    setJobMessage('');
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this job?')) return;
    try {
      await deleteJob(id);
      if (editingJobId === id) {
        setEditingJobId(null);
        setJobForm(emptyJob);
      }
      await refreshJobs();
    } catch (error) {
      setJobMessage(error.message);
    }
  };

  const filteredJobs = useMemo(() => {
    return jobsData.filter((job) => {
      const matchesSearch = [job.title, job.company, job.location, job.description]
        .join(' ')
        .toLowerCase()
        .includes(search.toLowerCase());
      const matchesType = filterType === 'All' || job.type === filterType;
      return matchesSearch && matchesType;
    });
  }, [filterType, jobsData, search]);

  // Resume upload and suggestion
  const [suggestedJobs, setSuggestedJobs] = useState([]);
  const [resumeText, setResumeText] = useState('');

  const handleResumeUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('text')) {
      // Only plain text resume parsing supported in this demo
      const reader = new FileReader();
      reader.onload = () => {
        const text = reader.result;
        setResumeText(text || '');
        suggestJobsFromText(text || '');
      };
      // try reading as text even for other types; may fail gracefully
      reader.readAsText(file);
    } else {
      const reader = new FileReader();
      reader.onload = () => {
        const text = reader.result;
        setResumeText(text || '');
        suggestJobsFromText(text || '');
      };
      reader.readAsText(file);
    }
  };

  const suggestJobsFromText = (text) => {
    const words = text
      .toLowerCase()
      .split(/[^a-z0-9]+/)
      .filter(Boolean);
    const counts = jobsData.map((job) => {
      const matches = job.keywords.reduce((acc, kw) => (words.includes(kw.toLowerCase()) ? acc + 1 : acc), 0);
      return { job, matches };
    });
    const suggestions = counts.filter((c) => c.matches > 0).sort((a, b) => b.matches - a.matches).map((c) => c.job);
    setSuggestedJobs(suggestions);
  };

  return (
    <>
      <div className="card form-card p-4 mb-4 d-flex justify-content-between align-items-center">
        <div>
          <h2 className="mb-0">Dashboard</h2>
          <p className="text-muted mb-0">Welcome back, {user.name}. Browse jobs and manage applications.</p>
        </div>
        <div>
          <button className="btn btn-outline-secondary me-2" onClick={() => { setSearch(''); setFilterType('All'); setSuggestedJobs([]); }}>
            Reset
          </button>
          <button className="btn btn-outline-secondary" onClick={onLogout}>
            Logout
          </button>
        </div>
      </div>

      <div className="row">
        <aside className="col-12 col-md-4 mb-4">
          <div className="card p-3 form-card mb-3">
            <h5 className="mb-2">{editingJobId ? 'Edit Job' : 'Post a Job'}</h5>
            {jobMessage && <div className="alert alert-info py-2">{jobMessage}</div>}
            <form onSubmit={handleJobSubmit}>
              {['title', 'company', 'location', 'salary'].map((field) => (
                <input
                  key={field}
                  className="form-control mb-2"
                  placeholder={field[0].toUpperCase() + field.slice(1)}
                  value={jobForm[field]}
                  onChange={(event) => setJobForm((previous) => ({ ...previous, [field]: event.target.value }))}
                  required={field !== 'salary'}
                />
              ))}
              <select className="form-select mb-2" value={jobForm.type} onChange={(event) => setJobForm((previous) => ({ ...previous, type: event.target.value }))}>
                <option>Full-time</option>
                <option>Part-time</option>
                <option>Contract</option>
              </select>
              <input className="form-control mb-2" placeholder="Keywords, comma separated" value={jobForm.keywords} onChange={(event) => setJobForm((previous) => ({ ...previous, keywords: event.target.value }))} />
              <textarea className="form-control mb-2" rows="3" placeholder="Description" value={jobForm.description} onChange={(event) => setJobForm((previous) => ({ ...previous, description: event.target.value }))} required />
              <button className="btn btn-success me-2" type="submit">{editingJobId ? 'Update Job' : 'Create Job'}</button>
              {editingJobId && <button className="btn btn-outline-secondary" type="button" onClick={() => { setEditingJobId(null); setJobForm(emptyJob); }}>Cancel</button>}
            </form>
          </div>
          <div className="card p-3 form-card mb-3">
            <h5 className="mb-2">Search & Filters</h5>
            <div className="mb-2">
              <input
                type="search"
                className="form-control"
                placeholder="Search jobs"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="mb-2">
              <select className="form-select" value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                <option value="All">All job types</option>
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
              </select>
            </div>
            <div className="mb-2">
              <label className="form-label mb-1">Top skills</label>
              <div className="d-flex flex-wrap gap-2">
                {['React', 'Node', 'Figma', 'Product', 'Remote'].map((t) => (
                  <button key={t} type="button" className="btn btn-sm btn-outline-success" onClick={() => setSearch(t)}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="card p-3 form-card">
            <h5 className="mb-2">Upload Resume</h5>
            <p className="text-muted small">Upload a resume to get suggested jobs based on keywords.</p>
            <input type="file" accept=".txt,.md,.pdf,.doc,.docx" onChange={handleResumeUpload} className="mb-2" />
            {resumeText && (
              <div className="preview p-2 bg-light border rounded" style={{ maxHeight: 120, overflow: 'auto' }}>{resumeText.slice(0, 800)}</div>
            )}
          </div>
        </aside>

        <main className="col-12 col-md-8">
          {loadError && <div className="alert alert-danger">{loadError}</div>}
          {suggestedJobs.length > 0 && (
            <div className="mb-4">
              <h5>Suggested Jobs</h5>
              <div className="row">
                {suggestedJobs.map((job) => (
                  <div className="col-12 col-md-6 mb-3" key={`s-${job.id}`}>
                    <JobCard job={job} />
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="row">
            {filteredJobs.length > 0 ? (
              filteredJobs.map((job) => (
                <div className="col-12 col-lg-6 mb-3" key={job.id}>
                  <JobCard job={job} />
                  <div className="d-flex gap-2 mt-2">
                    <button className="btn btn-sm btn-outline-primary" onClick={() => startEditing(job)}>Edit</button>
                    <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(job.id)}>Delete</button>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-12">
                <div className="alert alert-warning">No jobs match your search or filter.</div>
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  );
}

export default Dashboard;
