import { useState } from 'react';
import InputField from '../components/InputField.jsx';

function Login({ onLogin }) {
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});

  const validate = (values) => {
    const newErrors = {};
    if (!values.email.trim()) newErrors.email = 'Email is required.';
    if (!values.password) newErrors.password = 'Password is required.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate(form);
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      onLogin(form)
        .then(() => setForm({ email: '', password: '' }))
        .catch((error) => setErrors({ email: error.message, password: error.message }));
    }
  };

  return (
    <div className="card form-card p-4 mb-4">
      <div className="card-body">
        <h2 className="card-title mb-3">Sign In</h2>
        <p className="text-muted">Use your registered credentials to access the dashboard.</p>
        <form noValidate onSubmit={handleSubmit}>
          <InputField
            label="Email address"
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            error={errors.email}
            placeholder="example@domain.com"
          />
          <InputField
            label="Password"
            name="password"
            type="password"
            value={form.password}
            onChange={handleChange}
            error={errors.password}
            placeholder="Enter your password"
          />
          <button type="submit" className="btn btn-success w-100">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

export default Login;
