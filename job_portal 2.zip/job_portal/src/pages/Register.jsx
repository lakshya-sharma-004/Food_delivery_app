import { useState } from 'react';
import InputField from '../components/InputField.jsx';

function Register({ onRegister }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'Applicant' });
  const [errors, setErrors] = useState({});
  const [submitError, setSubmitError] = useState('');

  const validate = (values) => {
    const newErrors = {};
    if (!values.name.trim()) newErrors.name = 'Please enter your name.';
    if (!values.email.trim()) newErrors.email = 'Email is required.';
    else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(values.email)) newErrors.email = 'Enter a valid email.';
    if (!values.password) newErrors.password = 'Password is required.';
    else if (values.password.length < 6) newErrors.password = 'Password must be at least 6 characters.';
    return newErrors;
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const validation = validate(form);
    setErrors(validation);
    if (Object.keys(validation).length === 0) {
      setSubmitError('');
      onRegister({ ...form })
        .then(() => {
          setForm({ name: '', email: '', password: '', role: 'Applicant' });
          alert('Registration successful! You can now login.');
        })
        .catch((error) => setSubmitError(error.message));
    }
  };

  return (
    <div className="card form-card p-4 mb-4">
      <div className="card-body">
        <h2 className="card-title mb-3">Create Account</h2>
        <p className="text-muted">Register and start exploring jobs with a responsive portal.</p>
        {submitError && <div className="alert alert-danger">{submitError}</div>}
        <form noValidate onSubmit={handleSubmit}>
          <InputField
            label="Full Name"
            name="name"
            type="text"
            value={form.name}
            onChange={handleChange}
            error={errors.name}
            placeholder="Enter your full name"
          />
          <InputField
            label="Email address"
            name="email"
            type="email"
            value={form.email}
            onChange={handleChange}
            error={errors.email}
            placeholder="example@domain.com"
          />
          <InputField
            label="Password"
            name="password"
            type="password"
            value={form.password}
            onChange={handleChange}
            error={errors.password}
            placeholder="Choose a strong password"
          />
          <div className="mb-3">
            <label className="form-label">Register As</label>
            <select name="role" className="form-select" value={form.role} onChange={handleChange}>
              <option>Applicant</option>
              <option>Employer</option>
            </select>
          </div>
          <button type="submit" className="btn btn-success w-100">
            Register
          </button>
        </form>
      </div>
    </div>
  );
}

export default Register;
